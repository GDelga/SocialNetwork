class DAOPreguntas {
    constructor(pool) {
        this.pool = pool;
    }

    crearPregunta(email, pregunta, respuestas, callback) {
        this.pool.getConnection(function (err, connection) {
            if (err) {
                callback(new Error("Error de conexión a la base de datos"))
            } else {
                //Inserta los datos de la pregunta en su tabla
                connection.query(
                    "INSERT INTO PREGUNTAS (CREADOR, PREGUNTA) " +
                    "VALUES (?, ?)",
                    [email, pregunta],
                    function (err, result) {
                        if (err) {
                            connection.release();
                            callback(new Error("Error de acceso a la base de datos"));
                        } else {
                            //Si se ha podido inserttar, creamos la query para insertar varias respuestas en su tabla
                            let query = "INSERT INTO RESPUESTAS (ID_PREGUNTA, ORIGINAL, RESPUESTA) VALUES ";
                            for (let i in respuestas) {
                                query += "(" + result.insertId + ", " + true + ", '" + respuestas[i] + "')";
                                if (i != respuestas.length - 1) query += ",";
                            }
                            connection.query(
                                query,
                                function (err) {
                                    connection.release();
                                    if (err) {
                                        callback(new Error("Error de acceso a la base de datos"));
                                    } else callback(null);
                                }
                            )
                        }
                    }
                )
            }
        })
    }

    addRespuesta(pregunta, respuesta, callback) {
        this.pool.getConnection(function (err, connection) {
            if (err) {
                callback(new Error("Error de conexión a la base de datos"))
            } else {
                connection.query(
                    //Inserta una nueva respuesta a una pregunta existente
                    "INSERT INTO RESPUESTAS (ID_PREGUNTA, ORIGINAL, RESPUESTA) " +
                    "VALUES (?, ?, ?)",
                    [pregunta, false, respuesta],
                    function (err, result) {
                        connection.release();
                        if (err) {
                            callback(new Error("Error de acceso a la base de datos"));
                        } else callback(null);
                    }
                )
            }
        })
    }

    verPregunta(pregunta, callback) {
        this.pool.getConnection(function (err, connection) {
            if (err) {
                callback(new Error("Error de conexión a la base de datos"))
            } else {
                connection.query(
                    //Seleccionamos los datos de la pregunta
                    "SELECT * FROM PREGUNTAS WHERE ID = ?",
                    [pregunta],
                    function (err, result) {
                        if (err) {
                            connection.release();
                            callback(new Error("Error de acceso a la base de datos"));
                        } else {
                            if (result.length == 1) {
                                let n_pregunta = result[0];
                                //Buscamos las respuestas de la preguntga
                                connection.query(
                                    "SELECT * FROM RESPUESTAS WHERE ID_PREGUNTA = ?",
                                    [pregunta],
                                    function (err, result) {
                                        connection.release();
                                        if (err) {
                                            callback(new Error("Error de acceso a la base de datos"));
                                        } else {
                                            callback(null, {
                                                respuestas: result,
                                                pregunta: n_pregunta
                                            });
                                        }
                                    }
                                )
                            } else {
                                connection.release();
                                callback(new Error("Error de acceso a la base de datos"));
                            }
                        }
                    }
                )
            }
        })
    }

    verAdivinarPregunta(pregunta, amigo, callback) {
        this.pool.getConnection(function (err, connection) {
            if (err) {
                callback(new Error("Error de conexión a la base de datos"))
            } else {
                //Buscamos los datos de la pregunta
                connection.query(
                    "SELECT * FROM PREGUNTAS WHERE ID = ?",
                    [pregunta],
                    function (err, result) {
                        if (err) {
                            connection.release();
                            callback(new Error("Error de acceso a la base de datos"));
                        } else {
                            if (result.length == 1) {
                                let n_pregunta = result[0];
                                //Buscamos todas las repuestas originales de la pregunta
                                connection.query(
                                    "SELECT * FROM RESPUESTAS WHERE ID_PREGUNTA=? AND ORIGINAL=?",
                                    [pregunta, true],
                                    function (err, result) {
                                        if (err) {
                                            connection.release();
                                            callback(new Error("Error de acceso a la base de datos"));
                                        } else {
                                            let respuestasOriginales = result;
                                            //Buscamos la respuesta que dió nestro amigo
                                            connection.query(
                                                "SELECT ID, RESPUESTA, RESPONDER.ID_PREGUNTA, ORIGINAL FROM RESPONDER JOIN RESPUESTAS ON RESPONDER.ID_RESPUESTA = RESPUESTAS.ID " +
                                                "WHERE ID_USUARIO =? AND RESPONDER.ID_PREGUNTA =?",
                                                [amigo, pregunta],
                                                function (err, result) {
                                                    if (err) {
                                                        connection.release();
                                                        callback(new Error("Error de acceso a la base de datos"));
                                                    } else {
                                                        if (result.length == 1) {
                                                            let respuestaCorrecta = [];
                                                            //Si la respuesta no estaba en las originales, la añadimos
                                                            if (!result[0].ORIGINAL) {
                                                                respuestaCorrecta = result;
                                                            } 
                                                            //Buscamos aleatoriamente otras respuestas no originales hasta rellenar las necesarias
                                                            connection.query(
                                                                "SELECT * FROM RESPUESTAS WHERE ID_PREGUNTA = ? AND ORIGINAL=? AND ID !=? " +
                                                                "ORDER BY RAND() LIMIT ?", //Mi limite es las respuestas originales - la respuesta que ha dado mi amigo
                                                                [pregunta, false, result[0].ID, (respuestasOriginales.length - respuestaCorrecta.length)],
                                                                function (err, result) {
                                                                    connection.release();
                                                                    if (err) {
                                                                        callback(new Error("Error de acceso a la base de datos"));
                                                                    } else {
                                                                        callback(null, {
                                                                            //Concatenar todas las respuestas
                                                                            respuestas: respuestasOriginales.concat(respuestaCorrecta, result),
                                                                            pregunta: n_pregunta
                                                                        })
                                                                    }
                                                                }
                                                            )
                                                        } else {
                                                            connection.release();
                                                            callback(new Error("Error de acceso a la base de datos"));
                                                        }
                                                    }
                                                }
                                            )
                                        }
                                    }
                                )
                            } else {
                                connection.release();
                                callback(new Error("Error de acceso a la base de datos"));
                            }
                        }
                    }
                )
            }
        })
    }

    responderPregunta(email, pregunta, respuesta, callback) {
        this.pool.getConnection(function (err, connection) {
            if (err) {
                callback(new Error("Error de conexión a la base de datos"))
            } else {
                //Insertar una respuesta de una persona
                connection.query(
                    "INSERT INTO RESPONDER (ID_USUARIO, ID_PREGUNTA, ID_RESPUESTA) " +
                    "VALUES (?, ?, ?)",
                    [email, pregunta, respuesta],
                    function (err, result) {
                        connection.release();
                        if (err) {
                            callback(new Error("Error de acceso a la base de datos"));
                        } else {
                            callback(null);
                        }
                    }
                )
            }
        })
    }

    buscarPreguntas(callback) {
        this.pool.getConnection(function (err, connection) {
            if (err) {
                callback(new Error("Error de conexión a la base de datos"))
            } else {
                //Buscar 5 preguntas aleatorias
                connection.query(
                    "SELECT DISTINCT * FROM PREGUNTAS ORDER BY RAND() " +
                    "LIMIT 5",
                    function (err, result) {
                        connection.release();
                        if (err) {
                            callback(new Error("Error de acceso a la base de datos"));
                        } else {
                            callback(null, result);
                        }
                    }
                )
            }
        })
    }

    //No se usa
    buscarPreguntasNoRespondidas(email, callback) {
        this.pool.getConnection(function (err, connection) {
            if (err) {
                callback(new Error("Error de conexión a la base de datos"))
            } else {
                //Buscar 5 preguntas no respondidas aleatoriamente
                connection.query(
                    "SELECT DISTINCT * FROM PREGUNTAS WHERE PREGUNTAS.ID NOT IN " +
                    "(SELECT ID_PREGUNTA FROM RESPONDER WHERE ID_USUARIO=?) ORDER BY RAND() " +
                    "LIMIT 5",
                    [email],
                    function (err, result) {
                        connection.release();
                        if (err) {
                            callback(new Error("Error de acceso a la base de datos"));
                        } else {
                            callback(null, result);
                        }
                    }
                )
            }
        })
    }

    heRespondido(email, pregunta, callback) {
        this.pool.getConnection(function (err, connection) {
            if (err) {
                callback(new Error("Error de conexión a la base de datos"))
            } else {
                //Buscamos si he respondido o no a una pregunta
                connection.query(
                    "SELECT * FROM RESPONDER WHERE ID_USUARIO=? AND ID_PREGUNTA=?",
                    [email, pregunta],
                    function (err, result) {
                        connection.release();
                        if (err) {
                            callback(new Error("Error de acceso a la base de datos"));
                        } else {
                            callback(null, result);
                        }
                    }
                )
            }
        })
    }

    listarRespuestasAmigos(email, pregunta, callback) {
        this.pool.getConnection(function (err, connection) {
            if (err) {
                callback(new Error("Error de conexión a la base de datos"))
            } else {
                //Busco entre mis amigos si han respondido a una pregunta, y si la han respondido me traigo el resultado
                //en caso de que la haya intentado adivinar pondrá ACERTADA o FALLADA, en otro caso el resultado es null 
                //y sabemos que no la hemos intentado adivinar
                connection.query(
                    "SELECT DISTINCT CORREO, NOMBRE, FOTO, RESULTADO FROM USUARIOS AS USER JOIN " +
                    "(SELECT HAN_RESPONDIDO.ID_USUARIO, RESULTADO FROM " +
                    "(SELECT * FROM RESPONDER_AMIGOS WHERE ID_PREGUNTA=?) AS RES_AMIGOS RIGHT OUTER JOIN " +
                    "(SELECT DISTINCT ID_USUARIO FROM RESPONDER AS RES JOIN " +
                    "(SELECT DISTINCT ID_AMIGO FROM AMIGOS WHERE amigos.ID_USUARIO=? AND amigos.ESTADO='ACEPTADO') " +
                    "AS AMI WHERE RES.ID_USUARIO = AMI.ID_AMIGO AND ID_PREGUNTA=?) AS HAN_RESPONDIDO " +
                    "ON RES_AMIGOS.ID_AMIGO = HAN_RESPONDIDO.ID_USUARIO) AS RESULTADO ON USER.CORREO = RESULTADO.ID_USUARIO",
                    [pregunta, email, pregunta],
                    function (err, result) {
                        connection.release();
                        if (err) {
                            callback(new Error("Error de acceso a la base de datos"));
                        } else {
                            callback(null, result);
                        }
                    }
                )
            }
        })
    }

    responderAmigo(email, pregunta, amigo, respuesta, puntos, callback) {
        this.pool.getConnection(function (err, connection) {
            if (err) {
                callback(new Error("Error de conexión a la base de datos"))
            } else {
                //Buscamos la respuesta dada por nuestro amigo
                connection.query(
                    "SELECT ID_RESPUESTA, RESPUESTA FROM RESPONDER JOIN RESPUESTAS ON RESPONDER.ID_RESPUESTA = RESPUESTAS.ID " +
                    "WHERE ID_USUARIO =? AND RESPONDER.ID_PREGUNTA =?",
                    [amigo, pregunta],
                    function (err, result) {
                        if (err) {
                            connection.release();
                            callback(new Error("Error de acceso a la base de datos"));
                        } else {
                            let resultado = "FALLADA";
                            let n_respuesta = result[0].RESPUESTA;
                            if (result[0].ID_RESPUESTA == respuesta) {
                                resultado = "ACERTADA";
                            }
                            //Insertamos el resultado de intentar adivinarlo
                            connection.query(
                                "INSERT INTO RESPONDER_AMIGOS (ID_USUARIO, ID_AMIGO, ID_PREGUNTA, RESULTADO) " +
                                "VALUES (?, ?, ?, ?)",
                                [email, amigo, pregunta, resultado],
                                function (err, result) {
                                    if (err) {
                                        connection.release();
                                        callback(new Error("Error de acceso a la base de datos"));
                                    } else {
                                        if (resultado == "ACERTADA") {
                                            //Si hemos acertado actualizamos los puntos
                                            connection.query(
                                                "UPDATE USUARIOS SET PUNTOS = ? WHERE CORREO = ? ",
                                                [puntos += 50, email],
                                                function (err, result) {
                                                    connection.release();
                                                    if (err) {
                                                        callback(new Error("Error de acceso a la base de datos"));
                                                    } else {
                                                        callback(null, {
                                                            puntos: puntos,
                                                            resultado: "acertado",
                                                            respuesta: n_respuesta
                                                        });
                                                    }
                                                }
                                            )
                                        } else {
                                            connection.release();
                                            callback(null, {
                                                puntos: puntos,
                                                resultado: "fallado",
                                                respuesta: n_respuesta
                                            });
                                        }
                                    }
                                }
                            )
                        }
                    }
                )
            }
        })
    }
}

/*IMPORTANTE!!!!!!!!
Exportar la clase para que el controlador tenga acceso a ella*/
module.exports = DAOPreguntas;